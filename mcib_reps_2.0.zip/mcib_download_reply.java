<?xml version="1.0" encoding="UTF-8"?>
<config xmlns="http://web-harvest.sourceforge.net/schema/1.0/config" scriptlang="groovy">


<var-def name="bot_task_properties">
	<datastore name="mcib_reports">
		SELECT * FROM @this
	</datastore>
</var-def> 

<var-def name="country_codes">
	<datastore name="A2_country_codes">
		SELECT * FROM @this
	</datastore>
</var-def> 

<var-def name="entity_types">
	<datastore name="entity_types">
		SELECT * FROM @this
	</datastore>
</var-def> 


<!-- <secrets-vault-get alias="mcib_bom" /> -->
	
<script><![CDATA[
	def BOT_CONFIG = [:]
	bot_task_properties.getWrappedObject().toList().each { property ->
		BOT_CONFIG.put(property.get("name").toString(), property.get("value").toString())
	}
	sys.defineVariable("BOT_CONFIG", BOT_CONFIG)
]]></script>

		
<robotics-flow>
<robot driver="universal" start-in-private="false" close-on-completion="true">
			<capability name ="SEARCH_ALL_WINDOWS" value="true"/>
			<capability name="CLOSE_ALL_WINDOWS" value="false"/>
		<script><![CDATA[
	
			
			//changed excel template 03/06/20
			//added country codes and entity types list 03/06/20
			//added log 04/06/20
			//changed to zoned time log 04/06/20
			//removed issue log excel 04/06/20
			//added billed pdf 04/06/20
			//changed image path from ds to Dir 15/06/20
			//added email script 17/06/20
			//added reply 18/06/20
			//mail reply updated with generic text and error 19/06/20
			//removed resident entity flag from input excel 19/06/20
			//skip record if country or entity type blank 22/06/20
			//execute vbs script 25/06/20 
			//move request after file has been processed 29/06/20
			//skip login 29/06/20
			//mahaloop 30/06/20
			//error mail 01/07/20
			//getting error while screen closing because of switchToExistingWindow --> line 780, sendkeys also
			//skip append to log and reply parts if getting error in bom portal 01/07/20
			//process not terminating-->temp fix 02/07/20 
			//mail script downloading attachment from reply mail too-also saving reply mail as 'RE'-> solved 02/07/20
			//add relogin-->not neeeded since session will be closed after 5 mins
			//getting error if save dialog not found--> while saving report
			//refresh mail 07/07/20
			//dynamic path in vbscript 10/07/20
			//add if report already download go to mail send mail to user to inform about technical error 10/07/20
			//add relogin bom portal 22/07/20----> works only if dialog logout is there 25/08/20
			//downloading reply mail attachments if subject has more than template 25/08/20 added condition to download request only test further
			//remove dot from entity code 23/07/20
			//capitalise entity code 23/07/20
			//add template fix where robot takes not only fixed template 23/07/20
			//change switchTo to swtchToExisting line 1288 mail reply 23/07/20
			//change mailOpenPath line 200 23/07/20
			
			//direstraits letter removed, tweak muebcyp02fg02 to used on bom while entering path to download report 
			//add create robotic, config folder, copy email.vbs and images to config next year
			//add validation to download report
			//add validation to send mail
			
			//add wait for element while downloading on bom portal bc of latency

			//error mail is received whenever report is not downloaded or login on BoM is unsuccessful
			
			//date
			import java.time.LocalDate;
			import java.time.LocalDateTime;
			import java.time.ZoneId;
			import java.time.format.DateTimeFormatter;
			//copy files
			import java.nio.file.Files //copy and move files
			import org.apache.commons.io.FileUtils;
			import java.io.File;
			import java.nio.file.StandardCopyOption.*; //move files
			import java.io.FileInputStream;
			import java.io.FileOutputStream;
			import java.util.*;
			import java.text.SimpleDateFormat;
			import java.nio.file.StandardCopyOption;
			//apache excel
			import org.apache.poi.xssf.usermodel.*;
			import org.apache.poi.ss.usermodel.*;
			import org.apache.poi.hssf.usermodel.*;
			import java.text.SimpleDateFormat;
			import org.apache.poi.ss.usermodel.DateUtil
			//window descriptor
			import com.workfusion.studio.rpa.recorder.api.*
			import com.workfusion.studio.rpa.recorder.api.types.*
			import com.workfusion.studio.rpa.recorder.api.custom.*
			import com.workfusion.studio.rpa.recorder.api.internal.representation.*
			import com.workfusion.bot.exception.*
			//read pdf
			import org.apache.pdfbox.pdmodel.PDDocument;
			import org.apache.pdfbox.text.PDFTextStripper;
			import org.apache.pdfbox.text.PDFTextStripperByArea;
			//json
			import org.json.simple.JSONArray;
			import org.json.simple.JSONObject;
			import java.io.FileWriter;
			import org.json.simple.parser.JSONParser;
			
			
			def direstraits =  "C:\\Users\\Muthe Udaya Sankar\\Desktop\\pro\\BARC\\MCIB\\Reports\\ABSA\\Customer\\Year 2020\\Robotic\\MCIB Report\\11 November\\20.11.20\\"//daily_path_str; //daily path
			def logExcelPath = "C:\\Users\\Muthe Udaya Sankar\\Desktop\\pro\\BARC\\MCIB\\Reports\\ABSA\\Customer\\Year 2020\\Robotic\\MCIB Report\\11 November\\November 2020.xlsx"//monthly_report_path_str; 
			def configPath = "C:\\Users\\Muthe Udaya Sankar\\Desktop\\pro\\BARC\\MCIB\\Reports\\ABSA\\Customer\\Year 2020\\Robotic\\MCIB Report\\config\\"//config_path;
			def openPath = "C:\\Users\\Muthe Udaya Sankar\\Desktop\\pro\\BARC\\MCIB\\Reports\\ABSA\\Customer\\Year 2020\\Robotic\\MCIB Report\\config\\Mail\\Open\\"//open_path;
			def currentDate = "2020-11-20"//current_date
			
			//CURRENT DATE
			LocalDate karanLocal = LocalDate.parse(currentDate);
			
			////DATASTORE
			//BOM PORTAL GROUP
			String group = (BOT_CONFIG.getWrappedObject().get("bom_portal_group").toString());
			//BOM PORTAL LINK
			String portal_link = (BOT_CONFIG.getWrappedObject().get("bom_portal_link").toString());
			//MAIL ADDRESS TO SEND
			String mail_to = (BOT_CONFIG.getWrappedObject().get("mail_to").toString());
			String mail_cc = (BOT_CONFIG.getWrappedObject().get("mail_cc").toString());
			//OUTLOOK
			String outlook_path = (BOT_CONFIG.getWrappedObject().get("outlook_path").toString());
			
			/* //SECRETS VAULT
			Map entryMap = secureEntryMap.getWrappedObject();
			com.freedomoss.crowdcontrol.webharvest.web.dto.SecureEntryDTO obj = entryMap.get("mcib_bom");
			user = obj.getKey().toString();
			pass = obj.getValue().toString(); */
			
			//Report not downloaded check- send mail to User
			boolean error_mail = false;
			String subject = "";
			String log_path = "";
			String sender = "";
			String cc = "";
			
			
			//////////////////////////ENTITY AND COUNTRY CODES///////////////////////
			HashMap<String,String> country_codes_map = new HashMap<String,String>();
			HashMap<String,String> entity_types_map = new HashMap<String,String>();
			String country_name_str = "";
			String country_code_str = "";
			String entity_type_str = "";
			String entity_type_code_str = "";	
			for(int i = 0; i < country_codes.size(); i++){
				country_name_str = country_codes.get(i).getAt("Country").toString();				
				country_code_str = country_codes.get(i).getAt("Code").toString();
				country_codes_map.put(country_name_str,country_code_str);	
			}
			for(int i = 0; i < entity_types.size(); i++){
				entity_type_str = entity_types.get(i).getAt("entity_type").toString();				
				entity_type_code_str = entity_types.get(i).getAt("code").toString();
				entity_types_map.put(entity_type_str,entity_type_code_str);	
			}

			//////////////////////////ENTITY AND COUNTRY CODES///////////////////////
			
			//date format for mail and request
			DateTimeFormatter mailOpenFormat = DateTimeFormatter.ofPattern("dd MMM yyyy");
			String mailOpen = karanLocal.format(mailOpenFormat);
			
			//date format to save report excel
			DateTimeFormatter logExcelDateFormat = DateTimeFormatter.ofPattern("MMMM yyyy");
			String logExcel_file = karanLocal.format(logExcelDateFormat);
			
			//path
			def emailScriptPath = configPath+"email.vbs";
			def requestOpenPath = openPath+"MCIB Report.xlsx";
			def mailOpenPath = openPath+"MCIB Report "+mailOpen+".msg";
			def tempTextPath = openPath+"temp.txt";
			String imagePath = configPath+"MCIB_REPORTS_IMAGES"; //WILL NEED TO COPY NEXT YEAR
			String pendingPath = configPath + "\\Mail\\Pending\\"
			log_path = direstraits+"log.txt";
			
			/////////////////////////////////////////////////////////////LOOP//////////////////////////////////////////////////////////////
			//for(int maha_loop = 0; maha_loop < 10; maha_loop++){ 
			if(!error_mail){//skip if detected error for request(because it will do the same request again)
			///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			sender = "";
			cc = "";
			
			//json elements
			JSONObject request = new JSONArray();
			JSONObject requestObj = new JSONObject();
			JSONArray recordArr = new JSONObject();
			
			//current time
			LocalDateTime kldt = LocalDateTime.now(ZoneId.of("GMT+04:00"));
			String tayme = karanLocal.toString() + " " + kldt.getHour().toString() + ":" + kldt.getMinute().toString();			
			
			//timestamp to save mail and request
			String excelTayme = karanLocal.toString() + "_" + kldt.getHour().toString() + kldt.getMinute().toString();
			String inputExcelName = "Request_"+ excelTayme+".xlsx";
			def inputExcelPath = direstraits+"\\"+inputExcelName;	//can be present or not
			String mailDailyName = "Mail_"+excelTayme+".msg";
			String mailDailyPath = direstraits+mailDailyName;
			
			
			/* removed because pending records will be stored in json and details will be sent in mail
			//MOVE OLD REQUEST TO PENDING FOLDER
			File openFolder = new File(openPath);
			File[] openFiles = openFolder.listFiles();
			for(File file : openFiles){
				if(file.getAbsolutePath().contains("MCIB Report.xlsx") || file.getAbsolutePath().contains(".msg")){
					File pending = new File(pendingPath+file.getName()) 
					Files.move(file.toPath(),pending.toPath())
					log.info("Moving Request to Pending Folder");
				}
			} */
			/* 
			/////////////////////////////////REFRESH MAIL////////////////////////////
			try{
				switchToExistingWindow(new WindowDescriptor("", "(?i).*\\QInbox\\E.*", false, true).toString(), 5000); //wait for 5s
			}catch(Exception e){
				openAndFocus(outlook_path,10000,300);
				sleep(10000);
				switchToExistingWindow(new WindowDescriptor("", "(?i).*\\QInbox\\E.*", false, true).toString(), 5000); //wait for 5s
			}
			
			sleep(3000);
			sendKeys('!sd')
			sleep(4000);
			/////////////////////////////////REFRESH MAIL////////////////////////////
			
			/////////////////////////////////EMAIL CHECK////////////////////////////
			//configure paths
			String mailPath = config_path+"mail.vbs"
			
			try{
				Runtime.getRuntime().exec("wscript "+ (char)34+mailPath+(char)34);
				sleep(30000);
				
			}catch (IOException e) {
				log.info("Error in Executing Mail Script->"+e);
				
			}
			*/
			//request file check(in open folder)
			boolean requestPresent = false;
			File requestOpen = new File(requestOpenPath);
			File requestDaily = new File(inputExcelPath);
			
			if(requestOpen.exists()){
				//move request to daily folder
				Files.move(requestOpen.toPath(),requestDaily.toPath(), StandardCopyOption.REPLACE_EXISTING);	
				log.info("Mail script successfully run.");
				requestPresent = true;
			}
			/* 
			//Move mail message to daily folder
			//get mail message path from open folder
			File[] openFolder = new File(openPath).listFiles();
			List<String> contents = new ArrayList<String>();     
        	for (File file : openFolder){
				if(file.isFile()){
					if(file.getAbsolutePath().contains(".msg")){
						mailOpenPath = file.getAbsolutePath();
					}
				}
			}
			
			File mailOpen = new File(mailOpenPath);
			File mailDaily = new File(mailDailyPath);
			if(mailOpen.exists()){
				//move request to daily folder
				Files.move(mailOpen.toPath(),mailDaily.toPath(), StandardCopyOption.REPLACE_EXISTING);	
			}
			
		
			//get sender and cc from text file 'temp'
			File tempText = new File(tempTextPath);
			if(tempText.exists()){
				BufferedReader br = new BufferedReader(new FileReader(tempText));
				sender = br.readLine();
				cc = br.readLine();
				if(cc == null){
					cc = "";
				}
				br.close();
			} */
			
			/////////////////////////////////EMAIL CHECK////////////////////////////
 			if(requestPresent){//if request file is present
			//////////////////////////////////////////////////////////////////////////////////////////////////
			//LOG FILE
			FileWriter fr = new FileWriter(log_path);
			BufferedWriter loginta = new BufferedWriter(fr);
			
			loginta.append("-------------------------------------------");
			loginta.newLine();
			loginta.append(tayme);
			loginta.newLine();
			loginta.newLine();

			
			/////////////////////////////////GATHER DATA////////////////////////////
			File inputFile1 = null;
			try{
				//FROM
				inputFile1 = new File(inputExcelPath);
				FileInputStream fis1 = new FileInputStream(inputFile1);
				XSSFWorkbook inputWorkbook1 = new XSSFWorkbook(fis1);
				XSSFSheet inputSheet1 = inputWorkbook1.getSheetAt(0); 
								
				int rowCount1 = inputSheet1.getLastRowNum();
				log.info(rowCount1+" rows in inputsheet: "+inputSheet1.getSheetName());
			
				
			    int currentRowIndex1=1;//CHANGE
							               
				Iterator rowIterator1 = inputSheet1.iterator();
				
			while(rowIterator1.hasNext())
			{
		
			
				Row currentRow1 = inputSheet1.getRow(currentRowIndex1);
				
				if(currentRow1 == null){log.info("Brokeman");break;}
				Cell blankCheck1 = currentRow1.getCell(0,Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
				if(blankCheck1 == null){log.info("Brokeman Cell");break;}
				
				//create json list
				JSONObject recordDetails = new JSONObject();
		
				String value = "";
				for(int currentCellIndex1 = 0; currentCellIndex1 < 10; currentCellIndex1++){//0-10//A-K
					Cell cellData1 = currentRow1.getCell(currentCellIndex1,Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
					DataFormatter formatter1 = new DataFormatter();
					value1 = formatter1.formatCellValue(cellData1);
					
						switch(currentCellIndex1){
							
							case 0:	//requestor name
								recordDetails.put("requestorName", value1);
								break;
							
							case 1://cost centre to be debited
								recordDetails.put("costCentre", value1);
								break;
								
							case 2://branch code/other details/staff account
								recordDetails.put("branchCode", value1);
								break;
							
							case 3://entity type
								value1 = value1.toUpperCase();//test before to see if uppercase in original csv
								if(entity_types_map.containsKey(value1)){
									recordDetails.put("entityType", entity_types_map.get(value1));
								}
								else if(value1.isEmpty() || value1 == ""){
									recordDetails.put("entityType", value1);
								}
								break;									
				

							case 4://country name for non-resident
								value1 = value1.toUpperCase();
								if(country_codes_map.containsKey(value1)){
									recordDetails.put("countryName", country_codes_map.get(value1));
								}
								else if(value1.isEmpty() || value1 == ""){
									recordDetails.put("countryName", value1);
								}
								break;
							
							case 6://entity code
								if(value1.contains(".")){
									value1 = value1.replace(".","");
								}
								value1 = value1.toUpperCase();
								recordDetails.put("entityCode", value1);
								break;

							case 5://entity name
								recordDetails.put("entityName", value1.trim());
								//println(value1.trim())
								break;

							case 7://mcib report format
								recordDetails.put("reportFormat", value1);
								break;
						
							
						}
				}
				currentRowIndex1++;
				//additional settings to add to json
				//report retrieval status
				recordDetails.put("reportDownloaded", "false");
				//billed status
				recordDetails.put("billed", "");
				//exception description
				recordDetails.put("exception", "");
				
				recordArr.add(recordDetails); //add to json array
				
			}
			inputWorkbook1.close();
			fis1.close();
			//details of records from excel
			requestObj.put("record_list", recordArr);
			//mail message path in daily folder
			requestObj.put("mailDailyPath", mailDailyPath);
			//mail sender
			requestObj.put("sender", sender);
			//mail cc
			requestObj.put("cc", cc);
			//mail sent status
			requestObj.put("mailSent", "false");
			request.put("request",requestObj); //add to json array
			
			
			}catch(Exception e){
			log.info("Error reading request file");
			//loginta.append("Error reading request file");
			//loginta.newLine();
			e.printStackTrace();} 
			
			/////////////////////////////////GATHER DATA////////////////////////////
			
			//Write JSON file
			try{
			
				FileWriter json = new FileWriter("C:\\Users\\Muthe Udaya Sankar\\Desktop\\request.json") 
	 
				json.write(request.toJSONString());
				json.flush();
	 
			}catch(Exception e) {
				log.info("Error writing to JSON while reading from request->"+e)();
			}
			
			

			 /* 
			//////////////////////////////////LOGIN SKIP////////////////////////////////
			boolean login_skip = false;
			try{
				switchToExistingWindow(new WindowDescriptor("", "(?i).*\\QOracle Developer\\E.*", false, true).toString(), 5000); //wait for 5s
				//re-login
				boolean logout_check = false;
				try{
					$(byImage("${imagePath}/logout_check.png")).getCoordinates();
					logout_check = true;
				}catch(Exception e){
					logout_check = false;			
				}
				
				if(logout_check == true){
					$(byImage("${imagePath}/logout_check_yes.png")).click();
					sleep(5000);
					sendKeys(user);
					sendKeys("{TAB}");
					sendKeys(pass);
					sendKeys("{TAB}");
					sendKeys(group);
					sendKeys("{TAB}");
					pressEnter();
					sleep(2000);
					log.info("Re-Login");
				}
				login_skip = true;
			}
			catch(Exception e){
				login_skip = false;
				println("window notta founda")
			}
			//skip login if already logged in or all records invalid
		 	if(!login_skip){
	 		////////////////////////////PRE-REQUISITES SERVLET////////////////////////
			
			
			//Oracle Application Server Forms Services--> title of bom portal window
			//openIE('http://10.103.2.128:7778/forms/frmservlet?config=bom');
			sendKeys('#r');
			switchTo().window('[class="#32770"][title="Run"]')
			sendKeys('iexplore');
			pressEnter();
			sleep(3000);
			switchToExistingWindow(new WindowDescriptor("", "(?i).*\\QInternet Explorer\\E.*", false, true).toString(), 5000); //wait for 5s
			sendKeys('{F4}');
			sendKeys(portal_link);
			pressEnter();
			
			
			boolean java_form_presence_bool = false;
			//presence of java applet
			while(!java_form_presence_bool){
	
				try{
					$(byImage("${imagePath}/form.png")).getCoordinates();
					java_form_presence_bool = true;
					log.info("Login Form Found");
					break;
				}catch(Exception e){
					java_form_presence_bool = false;
					log.info("Dialog Found!");
				}
				
				
				//java update dialog
				//${imagePath}/run_this_time.png -->put all in same path
				sleep(2000);
				boolean java_update_check_bool = false;
				try{
					$(byImage("${imagePath}/run_this_time.png")).getCoordinates();
					java_update_check_bool = true;				
				}catch(Exception e){
					java_update_check_bool = false;
				}
				if(java_update_check_bool == true){
					$(byImage("${imagePath}/run_this_time.png")).click();
					log.info("Java Update passed");			
				}
				
				//java security dialog 0
				boolean java_security_check_bool_0 = false;
				try{
					$(byImage("${imagePath}/run2.png")).getCoordinates();
					java_security_check_bool_0 = true;
				}catch(Exception e){
					java_security_check_bool_0 = false;			
				}
				
				if(java_security_check_bool_0 == true){	
					$(byImage("${imagePath}/run.png")).click();
					log.info("Java Security 1(Run) passed");	
				}

				
				
				//java security dialog 1
				boolean java_update_check_bool_1 = false;
				try{
					$(byImage("${imagePath}/run2.png")).getCoordinates();
					java_update_check_bool_1 = true;				
				}catch(Exception e){
					java_update_check_bool_1 = false;
				}
				if(java_update_check_bool_1 == true){
					$(byImage("${imagePath}/run2.png")).click();
					log.info("Java Security 2(Run) passed");			
				}

				
				//java security dialog 2
				boolean java_security_check_bool_2 = false;
				try{
					$(byImage("${imagePath}/run_checkbox.png")).getCoordinates();
					$(byImage("${imagePath}/run.png")).getCoordinates();
					java_security_check_bool_2 = true;
				}catch(Exception e){
					java_security_check_bool_2 = false;			
				}
				
				if(java_security_check_bool_2 == true){
					$(byImage("${imagePath}/run_checkbox.png")).click();	
					$(byImage("${imagePath}/run.png")).click();
					log.info("Java Security 3(Run) passed");	
				}
				
		
				//java security dialog 3
				boolean java_security_check_bool_3 = false;
				try{
					$(byImage("${imagePath}/continue.png")).getCoordinates();
					java_security_check_bool_3 = true;
				}catch(Exception e){
					java_security_check_bool_3 = false;
				}
				if(java_security_check_bool_3 == true){
						$(byImage("${imagePath}/continue.png")).click();
						log.info("Java Security 4(Continue) passed");	
				}
				
				
				//java security dialog 4
				boolean java_security_check_bool_4 = false;
				try{
					$(byImage("${imagePath}/unblock.png")).getCoordinates();
					java_security_check_bool_4 = true;
				}catch(Exception xamal){
					java_security_check_bool_4  = false;
				}
				
				if(java_security_check_bool_4 == true){	
					$(byImage("${imagePath}/unblock.png")).click();
					log.info("Java Security 5(Unblock) passed");		
				}
				
				//java security dialog 5
				boolean java_update_check_bool_5 = false;
				try{
					$(byImage("${imagePath}/java_yes.png")).getCoordinates();
					java_update_check_bool_5 = true;				
				}catch(Exception e){
					java_update_check_bool_5 = false;
				}
				if(java_update_check_bool_5 == true){
					$(byImage("${imagePath}/java_yes.png")).click();
					log.info("Java Security 6(Yes) passed");			
				} 
		
				//error dialog
				boolean error_dialog_bool = false;
				try{
					$(byImage("${imagePath}/ok.png")).getCoordinates();
					error_dialog_bool = true;
				}catch(Exception e){
					error_dialog_bool = false;
				}
				if(error_dialog_bool == true){
					$(byImage("${imagePath}/ok.png")).click();
					log.info("Error Dialog passed");
				}
			
			}
			
			
		sleep(2000);
		
		///////////////////PRE-REQUISITES////////////////////////////
		
		
		
		////////////////////////////////////LOGIN MCIB//////////////////////////////////
		try{
			switchToExistingWindow(new WindowDescriptor("", "(?i).*\\QOracle Developer\\E.*", false, true).toString(), 5000); //wait for 5s
			sendKeys(user);
			sendKeys("{TAB}");
			sendKeys(pass);
			sendKeys("{TAB}");
			sendKeys(group);
			sendKeys("{TAB}");
			pressEnter();
			sleep(2000); 
		}catch(Exception e){
			log.info("Error while entering credentials");
			
		}
		/////////////////////////////////////////////////////////////////////////////
		}
		//////////////////////////////////LOGIN SKIP////////////////////////////////
		
		
		//login successful check
		boolean login_success = true;
		try{
			$(byImage("${imagePath}/logout_2.png")).getCoordinates();
			login_success = true;
		}catch(Exception e){
			login_success = false;
			log.info("Login Unsucessful");
			loginta.append("Login Unsucessful");
			loginta.newLine();
			subject = "Login Unsuccessful on BoM portal.";
			error_mail = true;
			
		}
		
		////////////////////////////////////LOGIN MCIB//////////////////////////////////

		 */	
		/////testy
		login_success = true;
		/////////////////////////////////////LOGIN CHECK///////////////////////////////////////
		if(login_success){
		///////////////////////////////////DOWNLOAD REPORT////////////////////////////////////
		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject = (JSONObject) jsonParser.parse(new FileReader("C:\\Users\\Muthe Udaya Sankar\\Desktop\\request.json"));
		JSONArray jsonArray = (JSONArray) jsonObject.get("request").get("record_list");
		
		
        //Iterating the contents of the array
        int jaz_size = jsonArray.size();
		outtaloop: for(int i = 0; i < jaz_size; i++){	
				
				JSONObject item = jsonArray.get(i)
				
				//check if report already downloaded
				if(item.get("reportDownloaded") == "false"){
					
				//loginta.newLine();
				log.info("Current Entity: "+item.getAt("entityCode"));
				//loginta.append("Current Entity: "+jsonArray.get("entityCode"));
				//loginta.newLine();
				//loginta.newLine();

				//validations of records
				//entity code
				if(item.get("entityCode").isEmpty() || item.get("entityCode") == ""){
					//loginta.append("Entity Code field not present for entity: ");
					//loginta.append(jsonArray.get("entityName"));
					//loginta.newLine();
					item.put("exception", item.getAt("entityName") + ": Entity Code field not present")
					continue outtaloop;
				}
				//country name
				if(item.getAt("countryName").isEmpty() || item.getAt("countryName") == ""){
					//loginta.append("Country Name field not present for entity: ");
					//loginta.append(jsonArray.get("entityName"));
					//loginta.newLine();
					item.put("exception", item.getAt("entityName") + ": Country Name field not present")
					continue outtaloop;
				}
				//entity type
				if(item.getAt("entityType").isEmpty() || item.getAt("entityType") == ""){
					//loginta.append("Entity Type field not present for entity: ");
					//loginta.append(jsonArray.get("entityName"));
					//loginta.newLine();
					item.put("exception", item.getAt("entityName") + ": Entity Type field not present")
					continue outtaloop;
				}
				
				//log.info("Entity Code: "+item.getAt("entityCode"))
				//jsonArray.add(item) 
				
		
				
			/* 	
				sendKeys("{ALT}");
				sendKeys("{RIGHT 5}");
				
				//////////////////////////////INDIVIDUAL/////////////////////////////////
				if(item.getAt("entityType").equalsIgnoreCase("I")){ //change accordingly
					
					log.info("Indie");
					//ENTER ON "INDIVIDUAL CREDIT PROFILE REPORT"
					sendKeys("{DOWN}");
					pressEnter();
					
					////////wait for individual form to load///////
					boolean indie_form = false;
					while(!indie_form){
						try{
							sleep(5000);
							$(byImage("${imagePath}/generate_reports.png")).getCoordinates();
							indie_form = true;				
						}catch(Exception e){
							indie_form = false;
							log.info("Wait for Individual Form to load");
						}
					}
					/////////////////////wait/////////////////////
					
					//ENTITY CODE(customer not available exception--to solve)
					sendKeys(item.getAt("entityCode"));
					sendKeys("{TAB}");
					sleep(1000);
					
					//ENTITY CODE EXCEPT(exit for resident, continue for non-resident)
					boolean entity_cust_except = false;
					try{
						$(byImage("${imagePath}/entity_code_except.png")).getCoordinates();
						entity_cust_except = true;				
					}catch(Exception e){
						entity_cust_except = false;
						log.info("nah bruuuh")
					}
					if(entity_cust_except == true){	//if customer not available
						pressEnter();
						log.info("Customer not available for participant: BARC");
						loginta.append("Customer not available for participant: BARC");
						loginta.newLine();
								
 					}
					
					
					//NON-RESIDENT
					if(item.getAt("countryName") != "MU"){	//change accordingly
						
						
						//sendkeys method of choosing non-resident does not work properly
						log.info("Non-Presidency");
		
						//NON-RESIDENT SELECT(byImage)
						boolean nri = false;
						try{
							$(byImage("${imagePath}/non_resident.png")).getCoordinates();
							nri = true;				
						}catch(Exception e){
							nri = false;
							log.info("Dropdown Not Found")
						}
						if(nri == true){
							$(byImage("${imagePath}/non_resident.png")).click();
							log.info("Dropdown Clicked");			
						}
						sendKeys("{DOWN}")
						pressEnter();
				
						//COUNTRY SELECT
						boolean country_bool = false;
						try{
							$(byImage("${imagePath}/country.png")).getCoordinates();
							country_bool = true;				
						}catch(Exception e){
							country_bool = false;
							log.info("nah bruuuh")
						}
						if(country_bool == true){
							$(byImage("${imagePath}/country.png",30,0)).click();
							log.info("Country Textbox Selected");			
						}
						sendKeys(item.getAt("countryName"));
						
					}
					
					
					//SAVE REPORTS TO DISK
					boolean save_bool = false;
					try{
						$(byImage("${imagePath}/save_reports.png")).getCoordinates();
						save_bool = true;				
					}catch(Exception e){
						save_bool = false;
						log.info("nah bruuuh")
					}
					if(save_bool == true){
						$(byImage("${imagePath}/save_reports.png")).click();
						log.info("Save Reports Selected");			
					}
					
				 	
					//GENERATE REPORTS
					boolean generate_bool = false;
					try{
						$(byImage("${imagePath}/generate_reports.png")).getCoordinates();
						generate_bool = true;				
					}catch(Exception e){
						generate_bool = false;
						log.info("report gen click error")
					}
					if(generate_bool == true){
						$(byImage("${imagePath}/generate_reports.png")).click();
						log.info("Generate Reports Selected");			
					}
					
					//NON ABSA
					boolean non_barc_indie = false;
					try{
						$(byImage("${imagePath}/non_barc.png")).getCoordinates();
						non_barc_indie = true;				
					}catch(Exception e){
						non_barc_indie = false;
						log.info("Customer does not have records with ABSA")
					}
					if(non_barc_indie == true){
						sendKeys("{LEFT}");
						pressEnter();						
					}
					
					
					
					//INVALID ENTITY(RESIDENT INDIVIDUAL) EXCEPTION
					boolean entity_except_res_indie = false;
					try{
						$(byImage("${imagePath}/resident_individual_invalid_entity_except.png")).getCoordinates();
						entity_except_res_indie = true;				
					}catch(Exception e){
						entity_except_res_indie = false;
					}
					if(entity_except_res_indie == true){
						pressEnter();
						log.info("Invalid Entity Code(Resident Individual)");	
						loginta.append("Invalid Entity Code(Resident Individual)");
						loginta.newLine();	
						item.put("billed", "N/A");
						item.put("exception", item.getAt("entityName") + " " + item.getAt("entityCode") + ": Invalid Entity Code(Resident Individual)")
						

						//EXIT
						boolean entity_except_indie_exit = false;
						try{
							$(byImage("${imagePath}/exit.png")).getCoordinates();
							entity_except_indie_exit = true;
							log.info("Exit Button Found");				
						}catch(Exception e){
							entity_except_indie_exit = false;
							log.info("Exit Button Not Found");
						}
						if(entity_except_indie_exit == true){
							$(byImage("${imagePath}/exit.png")).click();
							log.info("Exit");
							loginta.append("Stopping process for this record");
							loginta.newLine();				
						}
						sleep(2000);
						
						continue outtaloop;
								
					}
					
					////////wait for explorer window to load///////
					boolean indie_explorer = false;
					while(!indie_explorer){
						try{
							sleep(5000);
							switchToExistingWindow(new WindowDescriptor("", "(?i).*\\QSave\\E.*", false, true).toString(), 60000);
							indie_explorer = true;				
						}catch(Exception e){
							indie_explorer = false;
							log.info("Waiting for explorer to input download path to load");
						}
					}
					/////////////////////wait/////////////////////
					
					//BROWSE & SAVE REPORT
					try{
						switchToExistingWindow(new WindowDescriptor("", "(?i).*\\QSave\\E.*", false, true).toString(), 60000);
						String temp_dir = direstraits+item.getAt("entityCode");
						temp_dir = "\\" + temp_dir 
						setClipboardText(temp_dir);
						pressCtrlV();
						pressEnter();
						switchToExistingWindow(new WindowDescriptor("", "(?i).*\\QOracle Developer\\E.*", false, true).toString(), 5000);
					}catch(Exception e){
						log.info("Failed to input path to save report")
					}
					//REPORT SAVED
					boolean file_success = false;
					try{
						$(byImage("${imagePath}/success.png")).getCoordinates(); 
						file_success = true;
						log.info("Report Successfully Saved");				
					}catch(Exception e){
						file_success = false;
						log.info("Report Not Downloaded");
						loginta.append("Report Not Downloaded");
						loginta.newLine();
						item.put("billed", "N/A");
						subject = "Error while generating report(s) on BoM portal. Latency problem.";
						error_mail = true;
					}
					if(file_success){
						pressEnter(); 
						log.info("Report Downloaded Successfully");
						loginta.append("Report Downloaded Successfully");
						loginta.newLine();
						item.add("reportDownloaded","true");
	
						//BILLED VERIFICATION 
						File koidneufDoc = new File(direstraits+item.getAt("entityCode")+".pdf")
						PDDocument document = PDDocument.load(koidneufDoc);
						boolean billed_yes = false;
						if (!document.isEncrypted()) {
							PDFTextStripperByArea stripper = new PDFTextStripperByArea();
							stripper.setSortByPosition(true);
							PDFTextStripper tStripper = new PDFTextStripper();
							String pdfFileInText = tStripper.getText(document);			               
							String[] lines = pdfFileInText.split("\\r?\\n");
							for (String line : lines) {
								if(line.contains("YES")){
									item.put("billed", "Y");	
									billed_yes = true;
									log.info("Billed: YES");
									break;
								}
								
							}
							if(!billed_yes){
								item.put("billed", "N");
								log.info("Billed: NO");
							}
						document.close();
						}
			            
			        }
					
					//EXIT
					boolean exit = false;
					try{
						$(byImage("${imagePath}/exit.png")).getCoordinates();
						exit = true;
						log.info("Exit Button Found");				
					}catch(Exception e){
						exit = false;
						log.info("Exit Button Not Found");
					}
					if(exit == true){
						$(byImage("${imagePath}/exit.png")).click();
						log.info("Exit");			
					}
				 
				}
				
				///////////////////////////////INDIVIDUAL/////////////////////////////////
				
				///////////////////////////////CORPORATE/////////////////////////////////
				if(!item.getAt("entityType").equalsIgnoreCase("I")){
				
					//ENTER ON "CORPORATE CREDIT PROFILE REPORT"
					sendKeys("{DOWN 2}");
					pressEnter();
					
					////////wait for corporate form to load///////
					boolean corp_form = false;
					while(!corp_form){
						try{
							sleep(5000);
							$(byImage("${imagePath}/generate_reports.png")).getCoordinates();
							corp_form = true;				
						}catch(Exception e){
							corp_form = false;
							log.info("Wait for Corporate Form to load");
						}
					}
					/////////////////////wait/////////////////////
					
					//NON-RESIDENT
					if(item.getAt("countryName") != "MU"){	
						sendKeys("{DOWN}");
					}
					
					sendKeys("{TAB}");
					
					//ENTITY TYPE
					sendKeys(item.getAt("entityType"));
					
					//ENTITY CODE
					sendKeys("{TAB}");
					
					//REMOVE C OR P
					String temp = item.getAt("entityCode")
					String first = "";
					if(item.getAt("entityType").equalsIgnoreCase("c") || item.getAt("entityType").equalsIgnoreCase("p")){
					first = String.valueOf(item.getAt("entityCode").charAt(0));
						if(first.equalsIgnoreCase("p") || first.equalsIgnoreCase("c")){
							temp = item.getAt("entityCode").substring(1,item.getAt("entityCode").length());
						}
					
					}
					
					
					sendKeys(temp);
					sendKeys("{TAB}")
					
					 //ENTITY CODE EXCEPT
					boolean entity_cust_corp_except = false;
						try{
							$(byImage("${imagePath}/entity_code_except.png")).getCoordinates();
							entity_cust_corp_except = true;				
						}catch(Exception e){
							entity_cust_corp_except = false;
						}
						if(entity_cust_corp_except == true){
							pressEnter();
							log.info("Customer not available for participant: BARC");
							loginta.append("Customer not available for participant: BARC");
							loginta.newLine();
										
 						}
					
					
					//NON-RESIDENT(CHOOSE COUNTRY)
					if(item.getAt("countryName") != "MU"){	
						boolean country_corp_bool = false;
						try{
							$(byImage("${imagePath}/country_corp.png")).getCoordinates();
							country_corp_bool = true;				
						}catch(Exception e){
							country_corp_bool = false;
							log.info("nah bruuuh")
						}
						if(country_corp_bool == true){
							$(byImage("${imagePath}/country_corp.png",100,0)).click();
							log.info("Country Textbox Selected");			
						}
						sendKeys(item.getAt("countryName"));
					}
					
					//SAVE REPORTS TO DISK
					boolean save_corp_bool = false;
					try{
						$(byImage("${imagePath}/save_reports.png")).getCoordinates();
						save_corp_bool = true;				
					}catch(Exception e){
						save_corp_bool = false;
						log.info("nah bruuuh")
					}
					if(save_corp_bool == true){
						$(byImage("${imagePath}/save_reports.png")).click();
						log.info("Save Reports Selected");			
					}
					
			 		
					//GENERATE REPORTS
					boolean generate_corp_bool = false;
					try{
						$(byImage("${imagePath}/generate_reports.png")).getCoordinates();
						generate_corp_bool = true;				
					}catch(Exception e){
						generate_corp_bool = false;
						log.info("report gen click error")
					}
					if(generate_corp_bool == true){
						$(byImage("${imagePath}/generate_reports.png")).click();
						log.info("Generate Reports Selected");			
					}
					
					
					//NON ABSA
					boolean non_barc_corp = false;
					try{
						$(byImage("${imagePath}/non_barc.png")).getCoordinates();
						non_barc_corp = true;				
					}catch(Exception e){
						non_barc_corp = false;
						log.info("Customer does not have records with ABSA")
					}
					if(non_barc_corp == true){
						sendKeys("{LEFT}");
						pressEnter();						
					}
					
					////////wait for explorer window to load///////
					boolean corp_explorer = false;
					while(!corp_explorer){
						try{
							sleep(5000);
							switchToExistingWindow(new WindowDescriptor("", "(?i).*\\QSave\\E.*", false, true).toString(), 60000);
							corp_explorer = true;				
						}catch(Exception e){
							corp_explorer = false;
							log.info("Waiting for explorer to input download path to load");
						}
					}
					/////////////////////wait/////////////////////
					
					//BROWSE & SAVE REPORT
					try{
						switchToExistingWindow(new WindowDescriptor("", "(?i).*\\QSave\\E.*", false, true).toString(), 60000);
						String temp_dir = direstraits+item.getAt("entityCode");
						temp_dir = "\\" + temp_dir 
						setClipboardText(temp_dir);
						pressCtrlV();
						pressEnter();
						switchToExistingWindow(new WindowDescriptor("", "(?i).*\\QOracle Developer\\E.*", false, true).toString(), 5000);
					}catch(Exception e){
						log.info("Failed to input path to save report")
					}
					
					//REPORT SAVED
					boolean file_success_corp = false;
					try{
						$(byImage("${imagePath}/success.png")).getCoordinates();
						file_success_corp = true;
						log.info("File Successfully Saved");				
					}catch(Exception e){
						file_success_corp = false;
						log.info("Report Not Downloaded");
						loginta.append("Report Not Downloaded");
						loginta.newLine();
						item.put("billed", "N/A");
						subject = "Error while generating report(s) on BoM portal. Latency problem.";
						error_mail = true;
					}
					if(file_success_corp == true){
						pressEnter();
						log.info("Report Downloaded Successfully");
						loginta.append("Report Downloaded Successfully");
						loginta.newLine();			
						item.add("reportDownloaded","true");
					
						//BILLED VERIFICATION (BYIMAGE REMOVED)
						File koidneufDoc = new File(direstraits+item.getAt("entityCode")+".pdf")
						PDDocument document = PDDocument.load(koidneufDoc);
						boolean billed_yes = false;
						if (!document.isEncrypted()) {
							PDFTextStripperByArea stripper = new PDFTextStripperByArea();
							stripper.setSortByPosition(true);
							PDFTextStripper tStripper = new PDFTextStripper();
							String pdfFileInText = tStripper.getText(document);			               
							String[] lines = pdfFileInText.split("\\r?\\n");
							for (String line : lines) {
								if(line.contains("YES")){
									item.put("billed", "Y");
									billed_yes = true;
									log.info("Billed: YES");
									break;
								}
								
							}
							if(!billed_yes){
								item.put("billed", "N");
								log.info("Billed: NO");
							}
							
					    }
					    document.close();
				   
					}
					
					//EXIT
					boolean exit_corp = false;
					try{
						$(byImage("${imagePath}/exit.png")).getCoordinates();
						exit_corp = true;
						log.info("Exit Button Found");				
					}catch(Exception e){
						exit_corp = false;
						log.info("Exit Button Not Found");
					}
					if(exit_corp == true){
						$(byImage("${imagePath}/exit.png")).click();
						log.info("Exit");			
					}
					 
					
				} 
		//////////////////////////////CORPORATE/////////////////////////////////
		*/
			}//report downloaded check
		}//loop end
		requestObj.put("record_list", jsonArray);
		request.put("request",requestObj);
		log.info("json array after bom portal->"+jsonArray)
		
		//Write JSON file
		try{
		
			FileWriter json = new FileWriter("C:\\Users\\Muthe Udaya Sankar\\Desktop\\request.json") 
 
			json.write(request.toJSONString());
			json.flush();
 
		}catch(Exception e) {
			log.info("Error writing to JSON while downloading report->"+e)();
		}
		////////////////////////////////////DOWNLOAD REPORT////////////////////////////////////
		 
		if(!error_mail){//skip log excel and mail reply if report not downloaded
 		//////////////////////////////////////APPEND LOG//////////////////////////////////////
		
		JSONParser jsonParser2 = new JSONParser();
		JSONObject jsonObject2 = (JSONObject) jsonParser.parse(new FileReader("C:\\Users\\Muthe Udaya Sankar\\Desktop\\request.json"));
		JSONArray jsonArray2 = (JSONArray) jsonObject.get("request").get("record_list");
		
		
		//PRESENCE CHECK DATE EXCEL
		File dateExcelFile = new File(logExcelPath);
		
		//WRITE TO EXCEL
		try{				
			//TO
			FileInputStream fisi2 = new FileInputStream(dateExcelFile);
				
			XSSFWorkbook outputWorkbook2 = new XSSFWorkbook(fisi2);
			XSSFSheet outputSheet2 = outputWorkbook2.getSheetAt(0);
			
		
			//FIND THE LAST WRITABLE ROW
			int lastCurrentRowIndex2 = 0;//DEAL CELL
			Iterator lastRowIterator2 = outputSheet2.iterator();
			while(lastRowIterator2.hasNext()){	
		
				Row lastCurrentRow2 = outputSheet2.getRow(lastCurrentRowIndex2);
				
				if(lastCurrentRow2 == null){
				
					lastCurrentRow2 = outputSheet2.createRow(lastCurrentRowIndex2);
					
				} 
				
				int currentCellIndex2 = 1;	//SECOND COLUMN
				Cell lastCellData2 = lastCurrentRow2.getCell(currentCellIndex2,Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
				CellType lastCurrentCellType2 = lastCellData2.getCellTypeEnum();
				
				if(lastCurrentCellType2 == CellType.BLANK){//2 IS BLANK CELL TYPE
					log.info("LAST ROW IN 'LOG': "+ lastCurrentRowIndex2);
					break;
				}
				lastCurrentRowIndex2++;
			}
			
			int printRowIndex2 = lastCurrentRowIndex2;//ROW TO WRITE
			
			log.info("Records in report->"+jsonArray2.size())
			
			//WRITE TO EXCEL           
			for(int i = 0; i < jsonArray2.size(); i++){
				
				JSONObject item = jsonArray2.get(i);
				
				int printCellIndex2 = 0;
				
				Row rowmiah = outputSheet2.getRow(printRowIndex2);
				if(rowmiah == null){
					rowmiah = outputSheet2.createRow(printRowIndex2);
				}
					
				String value = "";
				for(int currentCellIndex1 = 0; currentCellIndex1 < 12; currentCellIndex1++){//0-12//A-M
					
						switch(currentCellIndex1){
							
							case 0:	//date
								Cell cellmiah = rowmiah.createCell(currentCellIndex1);
								cellmiah.setCellValue(karanLocal.toString());
								break;
							
							case 1://requestor name
								Cell cellmiah = rowmiah.createCell(currentCellIndex1);
								cellmiah.setCellValue(item.getAt("requestorName"));
								break;
								
							case 2://cost centre to be debited
								Cell cellmiah = rowmiah.createCell(currentCellIndex1);
								cellmiah.setCellValue(item.getAt("costCentre"));
								break;
							
							case 3://branch code/other details/staff account
								Cell cellmiah = rowmiah.createCell(currentCellIndex1);
								cellmiah.setCellValue(item.getAt("branchCode"));
								break;									
				

							case 4://entity type
								Cell cellmiah = rowmiah.createCell(currentCellIndex1);
								cellmiah.setCellValue(item.getAt("entityType"));
								break;
							
							case 5://entity code
								Cell cellmiah = rowmiah.createCell(currentCellIndex1);
								cellmiah.setCellValue(item.getAt("entityCode"));
								break;
								
							case 6://country name for non-resident
								Cell cellmiah = rowmiah.createCell(currentCellIndex1);
								cellmiah.setCellValue(item.getAt("countryName"));
								break;

							case 7://entity name
								Cell cellmiah = rowmiah.createCell(currentCellIndex1);
								cellmiah.setCellValue(item.getAt("entityName"));
								break;
								
							case 8://mcib report format
								Cell cellmiah = rowmiah.createCell(currentCellIndex1);
								cellmiah.setCellValue(item.getAt("reportFormat"));
								break;
							
							case 9://billed status
								Cell cellmiah = rowmiah.createCell(currentCellIndex1);
								cellmiah.setCellValue(item.getAt("billed"));
								break;
							
							case 10://sender
								Cell cellmiah = rowmiah.createCell(currentCellIndex1);
								//cellmiah.setCellValue(item.getAt("sender"));--->sender is not kept in array
								break;
							
						}
				}		
				printRowIndex2++;
						
						
			}
			FileOutputStream fos2 = new FileOutputStream(dateExcelFile);
			fisi2.close();
			outputWorkbook2.write(fos2);
			fos2.close();
			log.info("Successfully written to Monthly Excel");
		
		
		}catch(Exception e){
			log.info("Error while writing to Log Excel->"+e);
			loginta.append("Error while writing to Log Excel");
			loginta.newLine();
		} 
			
		//////////////////////////////////////APPEND LOG//////////////////////////////////////
		
	/* 
		////////////////////////////////////////////REPLY MAIL//////////////////////////////////////////////
		JSONParser jsonParser3 = new JSONParser();
		JSONObject jsonObject3 = (JSONObject) jsonParser.parse(new FileReader("C:\\Users\\Muthe Udaya Sankar\\Desktop\\request.json"));
		JSONArray jsonArray3 = (JSONArray) jsonObject.get("request").get("record_list");
		String mailDailyPath2 = jsonObject2.get("request").get("mailDailyPath").toString();
		log.info("Location of mail message->"+mailDailyPath2)
		try{
		setClipboardText(mailDailyPath2);//dailypath
		sendKeys('#r');
		switchTo().window('[class="#32770"][title="Run"]');
		//sendKeys(mailOpenPath)
		pressCtrlV();
		pressEnter();
		switchToExistingWindow(new WindowDescriptor("rctrl_renwnd32", "(?i).*\\QMCIB Report\\E.*", false, true).toString(), 5000); //added class name to select only outlook window
		$('[CLASS:NetUIRibbonButton;NAME:Reply All]').click();
		
		boolean reportDownloadedCheck = false;
		
		//attach all reports
		for(int i = 0; i < jsonArray3.size(); i++){
			
			JSONObject item = jsonArray3.get(i);
			if(item.getAt("reportDownloaded") == "true"){
				switchToExistingWindow(new WindowDescriptor("rctrl_renwnd32", "(?i).*\\QRE: MCIB Report\\E.*", false, true).toString(), 5000); //wait for 5s
				sendKeys('!n');//alt n
				sendKeys('afb');//attach file, browse
				switchTo().window('[class="#32770"][title="Insert File"]');	//insert file window
				def tempPath = direstraits+item.getAt("entityCode")+".pdf";
				setClipboardText(tempPath)
				pressCtrlV();
				pressEnter();
				
				reportDownloadedCheck = true;
			}
		}
		
		switchToExistingWindow(new WindowDescriptor("rctrl_renwnd32", "(?i).*\\QRE: MCIB Report\\E.*", false, true).toString(), 5000); //wait for 5s
		
		 //generic text in body
		sendKeys("Hi All,")
		pressEnter();
		if(reportDownloadedCheck){
			sendKeys("Please Find Attached Report")
		}
		else{
			sendKeys("Please find comments below")
		}
		pressEnter();
		pressEnter();
		//add entity error in mail body
		for(int i = 0; i < jsonArray3.size(); i++){
			JSONObject item = jsonArray3.get(i);
			if(!item.getAt("exception").isEmpty() || !item.getAt("exception") != ""){ //test for isEmpty()
				sendKeys(item.getAt("exception"));
				pressEnter();
			}
		}
		
		
		//send mail
		switchToExistingWindow(new WindowDescriptor("rctrl_renwnd32", "(?i).*\\QRE: MCIB Report\\E.*", false, true).toString(), 5000); //wait for 5s
		$('[CLASS:Button;NAME:Send]').click();	
		//$('[CLASS:NetUIAppFrameHelper;NAME:Close]').click();	
		
		
		//close mail form
		//switchTo().window('[CLASS:rctrl_renwnd32;TITLE:MCIB Report '+mailOpen+' - Message (HTML)]');
		switchToExistingWindow(new WindowDescriptor("rctrl_renwnd32", "(?i).*\\QMCIB Report\\E.*", false, true).toString(), 5000); //wait for 5s
		$('[CLASS:Button;NAME:Close]').click(); //close button 
		
		
		loginta.append("Reply sent to "+sender);
		loginta.newLine();
		loginta.append("CC: "+cc);
		loginta.newLine();
		
		//DELETE JSON FILE AFTER EXECUTION
		File jsonFile = new File(jsonFilePath);
		jsonFile.delete();
		
		//move mail to close-------->>remove or not
		File mailOpenFile = new File(mailOpenPath);
		String dailyFolderCloseStr = dailyFolderClose.toPath();
		File mailCloseFile = new File(dailyFolderCloseStr+"\\"+mailCloseName);
		Files.move(mailOpenFile.toPath(),mailCloseFile.toPath());
		requestOpen.delete();//delete request from open	
		log.info("Mail moved to close folder")
		}catch(Exception e){
			log.info("Error sending mail");
			loginta.append("Error sending mail");
			loginta.newLine();
		}  */
		////////////////////////////////////////////REPLY MAIL//////////////////////////////////////////////
		//}//json loop
		}//skip log excel and mail reply if report not downloaded
		////////////////////////////////////////////////////////////////////////////////////////////////////	
	 	else{
			//move mail to pending
		}
		
		
		
 		}//login skip
		////////////////////////////////////////////LOGIN CHECK/////////////////////////////////////////////
			
			
	loginta.append("-------------------------------------------");
	loginta.newLine();
	loginta.newLine();
	loginta.close(); 
	///////////////////////////////////////////////////////////////////////////////////////////////////////
	}//request presence check
	 
	//////////////////////////////////////////////////////////////////////////////////////////////////////
	
	/////////////////////////////////////////////////////////////LOOP//////////////////////////////////////////////////////////////
	
	}//error mail
	//}//loop
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	
]]></script>

</robot>
</robotics-flow>

<!-- <case>
    <if condition="${error_mail}">
    	<mail smtp-host="mail.absa.co.za"
		    smtp-port="25"
		    type="html"
			from = "MUMCIBRobot@absa.africa"
			to = 	"${mail_to}"
		    subject="MCIB Reports" 
			>
			<var name="subject"/>Request received from <var name= "received_from"/>
			<![CDATA[<hr><em>]]>
				Generated by BotZerr, your friendly neighborhood bot
			<![CDATA[</em>]]>
			<mail-attach name="log.txt">
			<file path="${log_path}" type="binary"/>
			</mail-attach>
		</mail>
    </if>
 </case> -->

		
    <export include-original-data="true"></export>

</config>